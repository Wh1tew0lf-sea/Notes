### 个人介绍

2021级山东警察学院学生





### 简介

我们知道，传统的编译过程大概可分为两个步骤：把源代码翻译成中间表示（IR），把IR翻译成机器码（或者由解释器来解释执行）。这三个层次也就是前端、中端、后端。

GCC编译器在设计时没有做好层次划分，你不能知道它的IR是什么样子的，它也不会提供接口让你操作IR，这导致了其前端后端的大量数据耦合在了一起。这样一来，GCC就很难支持新的编程语言或者架构。

如果有一个大家都使用的开放的IR，那么每种新语言只需要一个新前端，每个新平台只需要一个新后端，这就比GCC方便的多。LLVM就是这一种项目。LLVM IR本质上一种与源编程语言和目标机器架构无关的通用中间表示，是LLVM项目的核心设计和最大的优势。

然后这里还出现了Clang。Clang是基于LLVM的编译器驱动，他可以把C/C++/OC等源码翻译成LLVM IR的前端，并经由LLVM的库成功由IR到后端。

![image-20221125160727428](C:\Users\17240\AppData\Roaming\Typora\typora-user-images\image-20221125160727428.png)

### LLVM基本用法

llvm主要具有以下几种格式的文件，其转换和关系图图中所示。

\1) a.c，源代码。

\2) a.bc，llvm的字节码的二进制形式。不可读的二进制IR，被称作位码（bitcode），用来给机器存储

\3) a.ll，llvm字节码的文本形式。给人看的版本，是一种可读的IR，类似于汇编代码，但其实它介于高等语言和汇编之间

\4) a.s，机器汇编码表示的汇编文件。

\5) a.out，可执行的二进制文件。

![image-20221125161456566](C:\Users\17240\AppData\Roaming\Typora\typora-user-images\image-20221125161456566.png)

使用clang可以直接把源代码（a.c）编译为本机可执行文件（a.out）。

`clang name.c -o name.out`

使用clang -emit-llvm -c可以把源代码（a.c）转换为llvm字节码的二进制格式文件（a.bc），并可以使用lli解释执行。

`clang -c -emit-llvm name.c -o name.bc`     

使用clang -emit-llvm -S可以把源代码（a.c）转换为llvm字节码的文本格式文件（a.ll）。

`clang -S -emit-llvm name.c -o name.ll`

使用llc可以把字节码的二进制格式文件（a.bc）转换为本地的汇编文件（a.s）。

`llc name.bc -o name.s`

a.ll和a.bc之间可以通过llvm-as和llvm-dis命令相互转换。
`llvm-as name.ll -o name.bc`                `llvm-dis name.bc -o name.ll`

 

一个基于LLVM后端的编译器的整体过程是

```text
.c --frontend--> AST --frontend--> LLVM IR --LLVM opt--> LLVM IR --LLVM llc--> .s Assembly --OS Assembler--> .o --OS Linker--> executable
```

**总结：**关于llvm的题目是无法通过工具直接得到c代码的，一般有三种方法

1.通过读.ll文件（字节码）来还原代码

2.通过读.s文件来还原代码

3.生成.out文件放到ida中反编译

我觉得能反编译的就反编译，就我来说看c还是比看那两种轻松很多的

### Babybc（数独约束求解）

知道了操作我们先来看道题目

给了一个.bc文件，我们转成.out反编译，这里扫描是64位ELF文件

```c
int __cdecl main(int argc, const char **argv, const char **envp)
{
  size_t v3; // rax
  unsigned __int64 v4; // rcx
  unsigned __int8 v5; // dl

  _isoc99_scanf(&unk_595, input, envp);
  if ( (unsigned int)strlen(input) == 25 )  //flag长度为25
  {
    if ( input[0] )
    {
      if ( (unsigned __int8)(input[0] - 48) > 5u ) //输入的ascii码不能大于5
        return 0;
      v3 = strlen(input);
      v4 = 1LL;
      while ( v4 < v3 )  //对输入进行遍历
      {
        v5 = input[v4++] - 48;
        if ( v5 > 5u )   //输入的每个字符ascii码不能大于5
          return 0;
      }
    }
    if ( (unsigned __int8)fill_number(input) && (unsigned __int8)docheck() )
      printf("CISCN{MD5(%s)}", input);
  }
  return 0;
}
```

跟进fill_number看一下

```c
char __fastcall fill_number(__int64 a1)
{
  char *v1; // rdi
  __int64 i; // rax
  char v3; // cl
  char v4; // cl
  char v5; // cl
  char v6; // cl
  char v7; // cl

  v1 = (char *)(a1 + 4);  //向后偏移四个字符
  for ( i = 0LL; i < 5; ++i )
  {
    v3 = *(v1 - 4);  //当前行的第一个字符
    if ( map[5 * i] )  //既然名称是map，很肯能是个二维数组
    {
      if ( v3 != 48 )
        return 0;
    }
// 分析每一个if/else，map不为0时，当前的输入字符必须是'0'；如果map为0，当前的map字符为输入字符的ascii码减去'0'的ascii码
    else
    {
      map[5 * i] = v3 - 48;
    }
    v4 = *(v1 - 3);  //当前行第二个字符
    if ( map[5 * i + 1] )
    {
      if ( v4 != 48 )
        return 0;
    }
    else
    {
      map[5 * i + 1] = v4 - 48;
    }
    v5 = *(v1 - 2);  //当前行第三个字符
    if ( map[5 * i + 2] )
    {
      if ( v5 != 48 )
        return 0;
    }
    else
    {
      map[5 * i + 2] = v5 - 48;
    }
    v6 = *(v1 - 1);  //当前行第四个字符
    if ( map[5 * i + 3] )
    {
      if ( v6 != 48 )
        return 0;
    }
    else
    {
      map[5 * i + 3] = v6 - 48;
    }
    v7 = *v1;  //当前行第五个字符
    if ( map[5 * i + 4] )
    {
      if ( v7 != 48 )
        return 0;
    }
    else
    {
      map[5 * i + 4] = v7 - 48;
    }
    v1 += 5;
  }
  return 1;
}
```

看一下map初始值

```
0,0,0,0,0
0,0,0,0,0
0,0,4,0,0
0,0,0,3,0
0,0,0,0,0
```

这里函数的功能就是：当map中的数值为0时，就转化为输入字符对应的0-5，取值为0-5；

​									当map中的数值不为0时，map值不变，且对应输值为字符0



再看docheck函数

```c
char docheck()
{
  __int64 v0; // rax
  __int64 v1; // rcx
  __int64 v2; // rcx
  __int64 v3; // rcx
  __int64 v4; // rcx
  __int64 v5; // rax
  __int64 v6; // rcx
  __int64 v7; // rcx
  __int64 v8; // rcx
  __int64 v9; // rcx
  __int64 v10; // rax
  char v11; // cl
  char v12; // cl
  char v13; // cl
  char v14; // cl
  __int64 v15; // rcx
  char result; // al
  char v17; // al
  char v18; // al
  char v19; // al
  char v20; // al
  char v21; // al
  int v22; // [rsp+0h] [rbp-10h]
  __int16 v23; // [rsp+4h] [rbp-Ch]
  int v24; // [rsp+8h] [rbp-8h]
  __int16 v25; // [rsp+Ch] [rbp-4h]

  v0 = 0LL;
  while ( 1 )
  {
    v25 = 0;
    v24 = 0;
    v1 = (unsigned __int8)map[5 * v0];          // map二维数组中，每行不能有两个数相同
    if ( *((_BYTE *)&v24 + v1) )
      break;
    *((_BYTE *)&v24 + v1) = 1;
    v2 = (unsigned __int8)map[5 * v0 + 1];
    if ( *((_BYTE *)&v24 + v2) )
      break;
    *((_BYTE *)&v24 + v2) = 1;
    v3 = (unsigned __int8)map[5 * v0 + 2];
    if ( *((_BYTE *)&v24 + v3) )
      break;
    *((_BYTE *)&v24 + v3) = 1;
    v4 = (unsigned __int8)map[5 * v0 + 3];
    if ( *((_BYTE *)&v24 + v4) )
      break;
    *((_BYTE *)&v24 + v4) = 1;
    if ( *((_BYTE *)&v24 + (unsigned __int8)map[5 * v0 + 4]) )
      break;
    if ( ++v0 >= 5 )
    {
      v5 = 0LL;
      while ( 1 )
      {
        v23 = 0;
        v22 = 0;
        v6 = (unsigned __int8)map[v5];          // map二维数组中，每列不能有两个数相同
        if ( *((_BYTE *)&v22 + v6) )
          break;
        *((_BYTE *)&v22 + v6) = 1;
        v7 = (unsigned __int8)map[v5 + 5];
        if ( *((_BYTE *)&v22 + v7) )
          break;
        *((_BYTE *)&v22 + v7) = 1;
        v8 = (unsigned __int8)map[v5 + 10];
        if ( *((_BYTE *)&v22 + v8) )
          break;
        *((_BYTE *)&v22 + v8) = 1;
        v9 = (unsigned __int8)map[v5 + 15];
        if ( *((_BYTE *)&v22 + v9) )
          break;
        *((_BYTE *)&v22 + v9) = 1;
        if ( *((_BYTE *)&v22 + (unsigned __int8)map[v5 + 20]) )
          break;
        if ( ++v5 >= 5 )
        {
          v10 = 0LL;
          while ( 1 )
          {
            v11 = row[4 * v10];                 // 根据row数组，添加了一些约束条件
            if ( v11 == 2 )
            {
              if ( (unsigned __int8)map[5 * v10] > (unsigned __int8)map[5 * v10 + 1] )
                return 0;
            }
            else if ( v11 == 1 && (unsigned __int8)map[5 * v10] < (unsigned __int8)map[5 * v10 + 1] )
            {
              return 0;
            }
            v12 = row[4 * v10 + 1];
            if ( v12 == 1 )
            {
              if ( (unsigned __int8)map[5 * v10 + 1] < (unsigned __int8)map[5 * v10 + 2] )
                return 0;
            }
            else if ( v12 == 2 && (unsigned __int8)map[5 * v10 + 1] > (unsigned __int8)map[5 * v10 + 2] )
            {
              return 0;
            }
            v13 = row[4 * v10 + 2];
            if ( v13 == 2 )
            {
              if ( (unsigned __int8)map[5 * v10 + 2] > (unsigned __int8)map[5 * v10 + 3] )
                return 0;
            }
            else if ( v13 == 1 && (unsigned __int8)map[5 * v10 + 2] < (unsigned __int8)map[5 * v10 + 3] )
            {
              return 0;
            }
            v14 = row[4 * v10 + 3];
            if ( v14 == 2 )
            {
              if ( (unsigned __int8)map[5 * v10 + 3] > (unsigned __int8)map[5 * v10 + 4] )
                return 0;
            }
            else if ( v14 == 1 && (unsigned __int8)map[5 * v10 + 3] < (unsigned __int8)map[5 * v10 + 4] )
            {
              return 0;
            }
            if ( ++v10 >= 5 )
            {
              v15 = 0LL;
              while ( 1 )
              {
                v17 = col[5 * v15];             // 根据col数组添加了一些约束条件
                if ( v17 == 2 )
                {
                  if ( (unsigned __int8)map[5 * v15] < (unsigned __int8)map[5 * v15 + 5] )
                    return 0;
                }
                else if ( v17 == 1 && (unsigned __int8)map[5 * v15] > (unsigned __int8)map[5 * v15 + 5] )
                {
                  return 0;
                }
                v18 = col[5 * v15 + 1];
                if ( v18 == 1 )
                {
                  if ( (unsigned __int8)map[5 * v15 + 1] > (unsigned __int8)map[5 * v15 + 6] )
                    return 0;
                }
                else if ( v18 == 2 && (unsigned __int8)map[5 * v15 + 1] < (unsigned __int8)map[5 * v15 + 6] )
                {
                  return 0;
                }
                v19 = col[5 * v15 + 2];
                if ( v19 == 2 )
                {
                  if ( (unsigned __int8)map[5 * v15 + 2] < (unsigned __int8)map[5 * v15 + 7] )
                    return 0;
                }
                else if ( v19 == 1 && (unsigned __int8)map[5 * v15 + 2] > (unsigned __int8)map[5 * v15 + 7] )
                {
                  return 0;
                }
                v20 = col[5 * v15 + 3];
                if ( v20 == 2 )
                {
                  if ( (unsigned __int8)map[5 * v15 + 3] < (unsigned __int8)map[5 * v15 + 8] )
                    return 0;
                }
                else if ( v20 == 1 && (unsigned __int8)map[5 * v15 + 3] > (unsigned __int8)map[5 * v15 + 8] )
                {
                  return 0;
                }
                v21 = col[5 * v15 + 4];
                if ( v21 == 2 )
                {
                  if ( (unsigned __int8)map[5 * v15 + 4] < (unsigned __int8)map[5 * v15 + 9] )
                    return 0;
                }
                else if ( v21 == 1 && (unsigned __int8)map[5 * v15 + 4] > (unsigned __int8)map[5 * v15 + 9] )
                {
                  return 0;
                }
                ++v15;
                result = 1;                     // 必须的到这里
                if ( v15 >= 4 )
                  return result;
              }
            }
          }
        }
      }
      return 0;
    }
  }
  return 0;
}
```

分析可知这是一道数独题，想要理解需要先理解指针，我之前一直对指针一知半解，这里又深入学习了一下

核心代码段是L33-L52，关键代码是形如*((_BYTE *)&v24 + v1) = 1;这样的代码，关键变量是v24、v25和map二维数组。

![image-20221125215528623](C:\Users\17240\AppData\Roaming\Typora\typora-user-images\image-20221125215528623.png)

有人说指针的本质是地址，有人说指针的本质是一个变量，这些理解虽然正确，但新手很难接受。事实上，指针的本质是**数据类型+地址**，很多ida的代码涉及**指针的强制类型转化**，比如**从char指针转化为int指针、short指针，或把int指针、short指针转化为char指针。**

![image-20221125215614376](C:\Users\17240\AppData\Roaming\Typora\typora-user-images\image-20221125215614376.png)

1）对于本题来说，**不要把v24和v25看成两个变量**，v24是int型4个字节，v25是short型2个字节，要把它们**合二为一**，看成是内存中连续6个字节的空间；给新手提供保姆图：

![image-20221125215712682](C:\Users\17240\AppData\Roaming\Typora\typora-user-images\image-20221125215712682.png)

2）L35: v1 = (unsigned __int8)map[5 * v0]; 表示取得当前map值（8字节的map填入64字节的v1的低8位，高56位补0），v1为一个0-5的整数。
3）L36:if ( *((_BYTE *)&v24 + v1) )紧接L37:break；显然，if中的表达式 *((_BYTE *)&v24 + v1) 不能为真，必须为0，否则，直接跳到L190:return 0; 该表达式中，连续6个8字节空间已赋值为0（L33、L34），*((_BYTE *)&v24 + v1) 可能指向6个6空间中的任一个，当然也为0。
4）接着来到L38的*((_BYTE *)&v24 + v1) = 1;即将这6个位置中的第v1个位置变为1，如果再不懂的话，保姆式的给出下图，这是假设v1为3的情况下，将相应的字节置1。
![image-20221125215801459](C:\Users\17240\AppData\Roaming\Typora\typora-user-images\image-20221125215801459.png)

5）如果上面的都看懂了，那么这道题已经解出来50%了，后面的很多代码都是一样的思路，接着看L39的v2 = (unsigned __int8)map[5 * v0 + 1];这行代码和L35一致，只是取得map当前行下一个元素的值，v2也为0-5之间的某一个值。L40：if ( *((_BYTE *)&v24 + v2) )，显然，该值应为false，满足该表达式为false的约束条件为：v1不等于v2，即`map[0][0]`不等于`map[0][1]`。
6）按上述思路继续分析，5次循环后，到L53条件为真，此时，**map矩阵中每行的元素为0-5中的值，且值不能相等。**
7）还是按照这种思路分析，L58到L77，分析略，结果为：**map矩阵中每列的元素为0-5中的值，且值不能相等。**

下面看看row和col的数组布局

```c
unsigned char row[] =
{
    0,   0,   0,   1,   
	1,   0,   0,   0,   
	2,   0,   0,   1,   
	0,   0,   0,   0,   
	1,   0,   1,   0, 
};
```

```c
unsigned char col[] =
{
  0, 0, 2, 0, 2, 
  0, 0, 0, 0, 0, 
  0, 0, 0, 1, 0, 
  0, 1, 0, 0, 1
};

```

8）row中的元素表示的是相邻的两个数的关系，如第一行第一个元素row[0]表示的是map[0][0]和map[0][1]的关系，如果这个值为1，表示左边的数大于右边的数；如果这个值为2，表示右边的数大于左边的数。再给个新手画一个保姆图吧，绿色的值为0、1或2，为1或2时，指明了两者的约束。
![image-20221125222331700](C:\Users\17240\AppData\Roaming\Typora\typora-user-images\image-20221125222331700.png)

再给个对照代码：

```c
unsigned char row[] =
{
    0,                      0,   0,                      1/*map[3]>map[4]*/,   
	1/*map[5]>map[6]*/,     0,   0,                      0,
	2/*map[10]<map[11]*/,   0,   0,                      1/*map[13]>map[14]*/,
	0,                      0,   0,                      0,
	1/*map[20]>map[21]*/,   0,   1/*map[22]>map[23]*/,   0, 
};
```


9）col元素表示的是相邻的两个数的关系，也照此分析，对照代码为：

```c
unsigned char col[] =
{
  0, 0,                     2/*(map[2]>map[7]*/, 0,                     2/*map[4]>map[9]*/, 
  0, 0,                     0,                   0,                     0, 
  0, 0,                     0,                   1/*(map[13]<map[18]*/, 0, 
  0, 1/*(map[16]<map[21]*/, 0,                   0,                     1/*map[19]<map[24]*/
};
```

到此为止所有条件就分析完了，手撕得到

```
1,4,2,5,3
5,3,1,4,2
3,5,4,2,1
2,1,5,3,4
4,2,3,1,5
```

答案需要替换原来的数为0

再看大佬脚本

```python
rowss = [[0x00, 0x00, 0x00, 0x01],[0x01, 0x00, 0x00, 0x00], [0x02, 0x00, 0x00, 0x01], [0x00, 0x00, 0x00, 0x00], [0x01, 0x00, 0x01, 0x00]]
colnms = [[0x00, 0x00, 0x02, 0x00,0x02], [0x00, 0x00, 0x00, 0x00, 0x00], [0x00, 0x00, 0x00, 0x01, 0x00], [0x00, 0x01, 0x00, 0x00, 0x01]]
from z3 import *
from hashlib import md5
s = Solver()
map = [[None]*5,[None]*5,[None]*5,[None]*5,[None]*5,]
for i in range(5):
    for j in range(5):
        map[i][j]=(Int("x%d%d"%(i, j)))
print(map)
s.add(map[2][2] == 4)
s.add(map[3][3] == 3)
for i in range(5):
    for j in range(5):
        s.add(map[i][j] >= 1)
        s.add(map[i][j] <= 5)
for i in range(5):
    for j in range(5):
        for k in range(j):
            s.add(map[i][j] != map[i][k])
for j in range(5):
    for i in range(5):
        for k in range(i):
            s.add(map[i][j] != map[k][j])
for i in range(5):
    for j in range(4):
        if rowss[i][j] == 1:
            s.add(map[i][j] > map[i][j+1])
        elif rowss[i][j] == 2:
            s.add(map[i][j] < map[i][j+1])
for i in range(4):
    for j in range(5):
        if colnms[i][j] == 2:
            s.add(map[i][j] > map[i+1][j])
        elif colnms[i][j] == 1:
            s.add(map[i][j] < map[i+1][j])
answer = s.check()
if answer == sat:
    print(s.model())
    m = s.model()
    flag = []
    for i in map:
        for j in i:
            flag.append(m[j].as_long())
    for i in range(len(flag)):
        flag[i] += 0x30
    flag[12] = 0x30
    flag[18] = 0x30
    flag = bytes(flag)
    print(md5(flag).hexdigest())
```



### LLVM的代码混淆

#### OLLVM

OLLVM是一款是由瑞士西北科技大学开发的一套开源的针对LLVM的代码混淆工具，旨在加强逆向的难度，整个项目包含数个包含独立功能的LLVM Pass，每个Pass会对应实现一种特定的混淆方式，通过这些Pass可以改变源程序的CFG和源程序的结构。

 **OLLVM有三大功能**，分别是：Instructions Substitution（**指令替换**）、Bogus Control Flow（**混淆控制流**）、Control Flow Flattening（**控制流平展**）。

（1）指令替换功能：随机选择一种功能上等效但更复杂的指令序列替换标准二元运算符；适用范围：加法操作、减法操作、布尔操作（与或非操作）且只能为整数类型。

（2）混淆控制流功能：1.在当前基本块之前添加基本块来修改函数调用图。2.原始基本块也被克隆并填充随机选择的垃圾指令。

（3）控制流平展功能：目的是完全展平程序的控制流程图。我自己的理解是if...else变为switch..case..语句。

##### 控制流平坦化实现

在逆向出题时，为了增加阅读难度从而提高安全性，可以使用LLVM Pass进行控制流平坦化。

这里从GitHub找了其实现的代码，也就是llvm pass

obfu.cpp

```c
#include "llvm/IR/Function.h"
#include "llvm/Pass.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/Instructions.h"
#include <vector>
#include <cstdlib>
#include <ctime>
using namespace llvm;
using std::vector;
 
namespace{
    struct Obfu : public FunctionPass{
        static char ID;
        Obfu() : FunctionPass(ID){}
 
        bool flatten(Function *f);
 
        bool runOnFunction(Function &F);
    };
}
 
bool Obfu::runOnFunction(Function &F){
    return flatten(&F);
}
 
bool Obfu::flatten(Function *f){
    IntegerType *int32Type = Type::getInt32Ty(f->getContext());
    // 遍历函数所有基本块，将其存到vector中
    vector<BasicBlock*> origBB;
    for(BasicBlock &BB: *f){
        origBB.push_back(&BB);
    }
    // 基本块数量不超过1则无需平坦化
    if(origBB.size() <= 1){
        return false;
    }
    // 从vector中去除第一个基本块
    origBB.erase(origBB.begin());
    BasicBlock *firstBB = &f->front();
    // 如果第一个基本块的末尾是条件跳转
    if(isa<BranchInst>(firstBB->getTerminator())){
        BranchInst *br = cast<BranchInst>(firstBB->getTerminator());
        if(br->isConditional()){
            CmpInst *cmpInst = cast<CmpInst>(firstBB->getTerminator()->getPrevNode());
            BasicBlock *newBB = firstBB->splitBasicBlock(cmpInst,"newBB");
            origBB.insert(origBB.begin(), newBB);
        }
    }
    // 创建循环
    BasicBlock *loopEntry = BasicBlock::Create(f->getContext(), "loopEntry", f, firstBB);
    BasicBlock *loopEnd = BasicBlock::Create(f->getContext(), "loopEnd", f, firstBB);
    firstBB->moveBefore(loopEntry);
    // 去除第一个基本块末尾的跳转
    firstBB->getTerminator()->eraseFromParent();
    // 初始化switch on变量
    srand(time(0));
    int randNumCase = rand();
    AllocaInst *swVarPtr = new AllocaInst(int32Type, 0, "swVar.ptr", firstBB);
    new StoreInst(ConstantInt::get(int32Type, randNumCase), swVarPtr, firstBB);
    // 使第一个基本块跳转到loopEntry
    BranchInst::Create(loopEntry, firstBB);
    // 在进入loopEntry读取switch on变量
    LoadInst *swVar = new LoadInst(int32Type, swVarPtr, "swVar", false, loopEntry);
    BranchInst::Create(loopEntry, loopEnd);
    // 初始化switch的default case
    // default case实际上不会被执行
    BasicBlock *swDefault = BasicBlock::Create(f->getContext(), "swDefault", f, loopEnd);
    BranchInst::Create(loopEnd, swDefault);
    SwitchInst *swInst = SwitchInst::Create(swVar, swDefault, 0, loopEntry);
    // 插入原基本块到switch中，仅是位置意义上的插入，而不是逻辑意义上的
    for(BasicBlock *BB : origBB){
        ConstantInt *numCase = cast<ConstantInt>(ConstantInt::get(int32Type, randNumCase));
        BB->moveBefore(loopEnd);
        swInst->addCase(numCase,BB);
        randNumCase = rand();
    }
    // 添加case
    for(BasicBlock *BB : origBB){
        // retn BB
        if(BB->getTerminator()->getNumSuccessors() == 0){
            continue;
        }
        // 非条件跳转
        if(BB->getTerminator()->getNumSuccessors() == 1){
            BasicBlock *sucBB = BB->getTerminator()->getSuccessor(0);
            BB->getTerminator()->eraseFromParent();
            ConstantInt *numCase = swInst->findCaseDest(sucBB);
            new StoreInst(numCase, swVarPtr, BB);
            BranchInst::Create(loopEnd, BB);
            continue;
        }
        // 条件跳转
        if(BB->getTerminator()->getNumSuccessors() == 2){
            ConstantInt *numCaseTrue = swInst->findCaseDest(BB->getTerminator()->getSuccessor(0));
            ConstantInt *numCaseFalse = swInst->findCaseDest(BB->getTerminator()->getSuccessor(1));
            BranchInst *br = cast<BranchInst>(BB->getTerminator());
            SelectInst *sel = SelectInst::Create(br->getCondition(), numCaseTrue, numCaseFalse, "", BB->getTerminator());
            BB->getTerminator()->eraseFromParent();
            new StoreInst(sel, swVarPtr, BB);
            BranchInst::Create(loopEnd, BB);
        }
    }
    return true;
}
 
char Obfu::ID = 0;
static RegisterPass<Obfu> X("obfu", "My obfuscating pass");
```

在此之前我们需要安装LLVM和clang编译器

首先我们先对上面的代码(LLVM Pass)进行重编译,这里我们使用命令行编译

```
clang `llvm-config --cxxflags` -Wl,-znodelete -fno-rtti -fPIC -shared obfu.cpp -o LLVMobfu.so `llvm-config --ldflags`
```

- `llvm-config`提供了`CXXFLAGS`与`LDFLAGS`参数方便查找LLVM的头文件与库文件。 如果链接有问题，还可以用`llvm-config --libs`提供动态链接的LLVM库。 具体`llvm-config`打印了什么，请自行尝试或查找官方文档。
- `-fPIC -shared` 显然是编译动态库的必要参数。
- 因为LLVM没用到RTTI，所以用`-fno-rtti` 来让我们的Pass与之一致。
- `-Wl,-znodelete`主要是为了应对LLVM 5.0+中加载ModulePass引起segmentation fault的bug。如果你的Pass继承了ModulePass，还请务必加上。

这样会生成一个LLVMobfu.so文件，之后我们就可以通过命令执行来使用它

```
clang -c -emit-llvm test.cpp -o obfu.bc
opt -load '/home/shu/桌面/ollvm/LLVMObfu.so' -obfu obfu.bc -o obfu.bc
llvm-dis obfu.bc -o obfu.ll
clang obfu.bc -o test
```



### [suctf 2019]hardcpp（控制流平坦化）

题目是个ELF64位可执行文件

为了展示一下去除与不去除控制流平坦化的区别，这里放一下未去除时的图片

![image-20221126124350937](C:\Users\17240\AppData\Roaming\Typora\typora-user-images\image-20221126124350937.png)

![image-20221126124401719](C:\Users\17240\AppData\Roaming\Typora\typora-user-images\image-20221126124401719.png)

去除需要ubuntu环境，并安装angr库，使用deflat.py脚本

`python3 deflat.py -f hardCpp --addr 0x4007E0``

![image-20221126124638340](C:\Users\17240\AppData\Roaming\Typora\typora-user-images\image-20221126124638340.png)

注意到“函数的开始地址为序言的地址”，因此我们需要在序言中找函数起始位置

![image-20221126124916442](C:\Users\17240\AppData\Roaming\Typora\typora-user-images\image-20221126124916442.png)

![image-20221126124815891](C:\Users\17240\AppData\Roaming\Typora\typora-user-images\image-20221126124815891.png)

至此就可以开始分析程序进行逆向了

```c
int __cdecl main(int argc, const char **argv, const char **envp)
{
  char v3; // al
  char v4; // al
  char v5; // al
  char v6; // al
  char v8; // al
  char v9; // al
  char v10; // al
  char v11; // al
  char v12[8]; // [rsp+A0h] [rbp-90h] BYREF
  char v13[8]; // [rsp+A8h] [rbp-88h] BYREF
  char v14[8]; // [rsp+B0h] [rbp-80h] BYREF
  char v15[8]; // [rsp+B8h] [rbp-78h] BYREF
  char v16[8]; // [rsp+C0h] [rbp-70h] BYREF
  char v17[7]; // [rsp+C8h] [rbp-68h] BYREF
  char v18; // [rsp+CFh] [rbp-61h]
  int v19; // [rsp+D0h] [rbp-60h]
  int v20; // [rsp+D4h] [rbp-5Ch]
  int v21; // [rsp+D8h] [rbp-58h]
  int v22; // [rsp+DCh] [rbp-54h]
  char input; // [rsp+E0h] [rbp-50h] BYREF
  char input1[23]; // [rsp+E1h] [rbp-4Fh] BYREF
  char v25[8]; // [rsp+F8h] [rbp-38h] BYREF
  char v26[8]; // [rsp+100h] [rbp-30h] BYREF
  char v27[8]; // [rsp+108h] [rbp-28h] BYREF
  char v28[4]; // [rsp+110h] [rbp-20h] BYREF
  int v29; // [rsp+114h] [rbp-1Ch]
  const char **v30; // [rsp+118h] [rbp-18h]
  int v31; // [rsp+120h] [rbp-10h]
  int v32; // [rsp+124h] [rbp-Ch]
  int v33; // [rsp+128h] [rbp-8h]
  bool v34; // [rsp+12Eh] [rbp-2h]
  bool v35; // [rsp+12Fh] [rbp-1h]

  v32 = 0;
  v31 = argc;
  v30 = argv;
  v29 = time(0LL);
  puts("func(?)=\"01abfc750a0c942167651c40d088531d\"?");// md5解码得到'#',告诉我们第一个字符是#
  input = getchar();
  fgets(input1, 21, stdin);
  v22 = time(0LL);
  v21 = 0;
  v33 = 0;
  if ( y >= 10 && ((((_BYTE)x - 1) * (_BYTE)x) & 1) != 0 )
    goto LABEL_13;
  while ( 1 )
  {
    v20 = strlen(&input);
    v34 = v20 != 21;
    if ( y < 10 || ((((_BYTE)x - 1) * (_BYTE)x) & 1) == 0 )
      break;
LABEL_13:
    v20 = strlen(&input);
  }
  while ( 1 )
  {
    v19 = 1;
    if ( y < 10 || ((((_BYTE)x - 1) * (_BYTE)x) & 1) == 0 )
      break;
    v19 = 1;
  }
  while ( v19 < 21 )
  {
    if ( y >= 10 && ((((_BYTE)x - 1) * (_BYTE)x) & 1) != 0 )
      goto LABEL_15;
    do
    {
      while ( 1 )
      {
        v18 = v21 ^ input1[v19 - 1];            // v18 = inp[v19-1]
        v17[0] = main::$_0::operator()((__int64)v27, v18);// v17[0] = inp[v19]
        v16[0] = main::$_1::operator()((__int64)v25, *(&input + v21 + v19 - 1));// v16[0] = inp[v19-1]
        v3 = main::$_1::operator() const(char)::{lambda(int)#1}::operator()(v16, 7);// v3 = inp[v19-1] % 7
        v18 = main::$_0::operator() const(char)::{lambda(char)#1}::operator()(v17, (unsigned int)v3);// v18 = inp[v19]+inp[v19-1]%7
        v15[0] = main::$_2::operator()(v28, (unsigned int)v18);// 将v18的值给v15[0]
        v14[0] = main::$_2::operator()(v28, (unsigned int)*(&input + v21 + v19 - 1));// v14[0] = inp[v19-1]
        v4 = main::$_2::operator() const(char)::{lambda(char)#1}::operator()(v14, 18LL);// v4 = inp[v19-1]^18
        v13[0] = main::$_3::operator()(v26, (unsigned int)v4);// v13[0] = inp[v19-1]^18
        v5 = main::$_3::operator() const(char)::{lambda(char)#1}::operator()(v13, 3);// v5 = (inp[v19-1]^18)*3
        v12[0] = main::$_0::operator()((__int64)v27, v5);// v12[0] = (inp[v19-1]^18)*3
        v6 = main::$_0::operator() const(char)::{lambda(char)#1}::operator()(v12, 2LL);// v6 = (inp[v19-1]^18)*3+2
        v18 = main::$_2::operator() const(char)::{lambda(char)#1}::operator()(v15, (unsigned int)v6);// v18 = ((inp[v19-1]^18)*3+2) ^ (inp[v19]+inp[v19-1]%7)
        v35 = enc[v19 - 1] != v18;              // enc[v19-1] = ((inp[v19-1]^18)*3+2) ^ (inp[v19]+inp[v19-1]%7)
        if ( y < 10 || ((((_BYTE)x - 1) * (_BYTE)x) & 1) == 0 )
          break;
LABEL_15:
        v18 = v21 ^ input1[v19 - 1];
        v17[0] = main::$_0::operator()((__int64)v27, v18);
        v16[0] = main::$_1::operator()((__int64)v25, *(&input + v21 + v19 - 1));
        v8 = main::$_1::operator() const(char)::{lambda(int)#1}::operator()(v16, 7);
        v18 = main::$_0::operator() const(char)::{lambda(char)#1}::operator()(v17, (unsigned int)v8);
        v15[0] = main::$_2::operator()(v28, (unsigned int)v18);
        v14[0] = main::$_2::operator()(v28, (unsigned int)*(&input + v21 + v19 - 1));
        v9 = main::$_2::operator() const(char)::{lambda(char)#1}::operator()(v14, 18LL);
        v13[0] = main::$_3::operator()(v26, (unsigned int)v9);
        v10 = main::$_3::operator() const(char)::{lambda(char)#1}::operator()(v13, 3);
        v12[0] = main::$_0::operator()((__int64)v27, v10);
        v11 = main::$_0::operator() const(char)::{lambda(char)#1}::operator()(v12, 2LL);
        v18 = main::$_2::operator() const(char)::{lambda(char)#1}::operator()(v15, (unsigned int)v11);
      }
    }
    while ( v35 );
    while ( y >= 10 && ((((_BYTE)x - 1) * (_BYTE)x) & 1) != 0 )
      ;
    ++v19;
  }
  if ( y < 10 || ((((_BYTE)x - 1) * (_BYTE)x) & 1) == 0 )
    goto LABEL_11;
  do
  {
    puts("You win");
LABEL_11:
    puts("You win");
  }
  while ( y >= 10 && ((((_BYTE)x - 1) * (_BYTE)x) & 1) != 0 );
  return 0;
}
```

两段函数是一样的，分析一段即可，每个函数跟进，注意返回值与取值，从这两方面进行分析

拆分开来看本题不难，就是代码量比较多。所以最后逻辑就是

`enc[v19-1] = ((inp[v19-1]^18)*3+2) ^ (inp[v19]+inp[v19-1]%7)`

exp：

```python
enc=[0xf3,0x2e,0x18,0x36,0xe1,0x4c,0x22,0xd1,0xf9,0x8c,0x40,0x76,0xf4,0xe,0x0,0x5,0xa3,0x90,0xe,0xa5]
flag='#'
for i in range(len(enc)):
    flag+=chr(((enc[i]^((ord(flag[-1])^18)*3+2))-(ord(flag[-1])%7))&0xff)
print(flag)
```

